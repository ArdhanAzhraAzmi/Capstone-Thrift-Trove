package com.dicoding.capstonui.view

import CartAdapter
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dicoding.capstonui.MainActivity
import com.dicoding.capstonui.R
import com.dicoding.capstonui.model.CartItem
import com.dicoding.capstonui.network.RetrofitClient
import kotlinx.coroutines.launch

class CartFragment : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var cartAdapter: CartAdapter // Ensure CartAdapter is imported correctly
    private lateinit var cartItems: List<CartItem>


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_cart, container, false)

        recyclerView = view.findViewById(R.id.recycler_view_cart)
        recyclerView.layoutManager = LinearLayoutManager(activity)

        fetchCartItems()

        val btnCheckout: Button = view.findViewById(R.id.btnCheckout)
        btnCheckout.setOnClickListener {
            performCheckout()
        }

        val ivBack: ImageView = view.findViewById(R.id.ivBack)
        ivBack.setOnClickListener {
            navigateToMainActivity()
        }

        return view
    }

    private fun fetchCartItems() {
        val token = getToken()
        val apiService = RetrofitClient.create(token)

        lifecycleScope.launch {
            try {
                val response = apiService.getCart()
                if (response.isSuccessful) {
                    cartItems = response.body() ?: emptyList()

                    // Set up RecyclerView with CartAdapter
                    cartAdapter = CartAdapter(cartItems)
                    recyclerView.adapter = cartAdapter
                } else {
                    Toast.makeText(
                        requireContext(),
                        "Failed to fetch cart items: ${response.errorBody()?.string()}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } catch (e: Exception) {
                Log.e("CartFragment", "Exception while fetching cart items", e)
                Toast.makeText(requireContext(), "An error occurred: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun performCheckout() {
        val token = getToken()
        val apiService = RetrofitClient.create(token)

        lifecycleScope.launch {
            try {
                val response = apiService.checkout(token)
                if (response.isSuccessful) {
                    Toast.makeText(requireContext(), "Checkout successful!", Toast.LENGTH_SHORT).show()
                    navigateToMainActivity()
                } else {
                    Toast.makeText(requireContext(), "Checkout failed: ${response.errorBody()?.string()}", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Log.e("CartFragment", "Exception during checkout", e)
                Toast.makeText(requireContext(), "An error occurred: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun getToken(): String {
        val sharedPrefs = requireContext().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
        return sharedPrefs.getString("token", "") ?: ""
    }

    private fun navigateToMainActivity() {
        val intent = Intent(requireActivity(), MainActivity::class.java)
        startActivity(intent)
    }
}
