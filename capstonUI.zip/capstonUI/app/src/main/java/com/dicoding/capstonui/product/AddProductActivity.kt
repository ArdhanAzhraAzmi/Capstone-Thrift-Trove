/*
package com.dicoding.capstonui.product

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.dicoding.capstonui.MainActivity
import com.dicoding.capstonui.R
import com.dicoding.capstonui.network.ApiService
import com.dicoding.capstonui.network.RetrofitClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File

class AddProductActivity : AppCompatActivity() {

    private lateinit var apiService: ApiService
    private lateinit var token: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_product)

        token = getToken()
        apiService = RetrofitClient.create(token)

        val name = intent.getStringExtra("name") ?: ""
        val description = intent.getStringExtra("description") ?: ""
        val price = intent.getStringExtra("price") ?: ""
        val imageFilePath = intent.getStringExtra("imageFile")

        Log.d("AddProductActivity", "Name: $name, Description: $description, Price: $price, ImageFilePath: $imageFilePath")

        if (name.isNotEmpty() && description.isNotEmpty() && price.isNotEmpty() && imageFilePath != null) {
            val imageFile = File(imageFilePath)
            addProduct(name, description, price, imageFile)
        } else {
            Toast.makeText(this, "Missing product details or image", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun getToken(): String {
        val sharedPrefs = getSharedPreferences("MyPrefs", MODE_PRIVATE)
        return sharedPrefs.getString("token", "") ?: ""
    }

    private fun addProduct(name: String, description: String, price: String, imageFile: File) {
        val nameRequestBody = name.toRequestBody("text/plain".toMediaTypeOrNull())
        val descriptionRequestBody = description.toRequestBody("text/plain".toMediaTypeOrNull())
        val priceRequestBody = price.toRequestBody("text/plain".toMediaTypeOrNull())
        val imageRequestBody = imageFile.asRequestBody("image/jpeg".toMediaTypeOrNull())
        val imageMultipartBody = MultipartBody.Part.createFormData("image", imageFile.name, imageRequestBody)

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val response = apiService.addProduct(
                    nameRequestBody,
                    descriptionRequestBody,
                    priceRequestBody,
                    imageMultipartBody
                )
                withContext(Dispatchers.Main) {
                    if (response.isSuccessful) {
                        val productId = response.body()?.id
                        Toast.makeText(applicationContext, "Product added successfully! ID: $productId", Toast.LENGTH_SHORT).show()
                        redirectToHomeFragment() // Redirect after success
                    } else {
                        Log.e("AddProductActivity", "Failed to add product: ${response.errorBody()?.string()}")
                        Toast.makeText(applicationContext, "Failed to add product", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Log.e("AddProductActivity", "Error: ${e.message}")
                    Toast.makeText(applicationContext, "An error occurred: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun redirectToHomeFragment() {
        val intent = Intent(this, MainActivity::class.java)
        intent.putExtra("fragment", "HomeFragment") // Pass data to switch fragment
        startActivity(intent)
    }
}
*/
