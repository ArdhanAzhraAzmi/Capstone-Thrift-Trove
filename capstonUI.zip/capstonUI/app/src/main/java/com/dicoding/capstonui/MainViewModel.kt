package com.dicoding.capstonui

import android.media.RouteListingPreference
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dicoding.capstonui.repository.Repository
import kotlinx.coroutines.launch

class MainViewModel(private val repository: Repository) : ViewModel() {

/*    private val _items = MutableLiveData<List<RouteListingPreference.Item>>()
    val items: LiveData<List<RouteListingPreference.Item>> get() = _items

    private val _cartItems = MutableLiveData<List<CartItem>>()
    val cartItems: LiveData<List<CartItem>> get() = _cartItems

    private val _itemDetail = MutableLiveData<RouteListingPreference.Item>()
    val itemDetail: LiveData<RouteListingPreference.Item> get() = _itemDetail

    private val _orderStatus = MutableLiveData<OrderStatus>()
    val orderStatus: LiveData<OrderStatus> get() = _orderStatus

    fun fetchItems() = viewModelScope.launch {
        val response = repository.getItems()
        if (response.isSuccessful) {
            _items.postValue(response.body())
        }
    }

    fun fetchItemById(id: String) = viewModelScope.launch {
        val response = repository.getItemById(id)
        if (response.isSuccessful) {
            _itemDetail.postValue(response.body())
        }
    }

    fun fetchCartItems(token: String) = viewModelScope.launch {
        val response = repository.getCart(token)
        if (response.isSuccessful) {
            _cartItems.postValue(response.body())
        }
    }

    fun trackOrder(orderId: String, token: String) = viewModelScope.launch {
        val response = repository.trackOrder(orderId, token)
        if (response.isSuccessful) {
            _orderStatus.postValue(response.body())
        }
    }*/

    // More functions for other actions like addItem, addItemToCart, etc.
}
