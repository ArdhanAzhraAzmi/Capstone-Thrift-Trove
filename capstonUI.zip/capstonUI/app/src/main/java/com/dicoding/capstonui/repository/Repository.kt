package com.dicoding.capstonui.repository

import com.dicoding.capstonui.login.LoginResponse
import com.dicoding.capstonui.network.ApiService
import com.dicoding.capstonui.signup.SignUpResponse
import retrofit2.Response

class Repository(private val apiService: ApiService) {

    suspend fun signUp(username: String, email: String, password: String): Response<SignUpResponse> {
        return apiService.signUp(username, email, password)
    }

    suspend fun login(username: String, password: String): Response<LoginResponse> {
        return apiService.login(username, password)
    }
}
/*
    suspend fun getItems(): Response<List<RouteListingPreference.Item>> {
        return apiService.getItems()
    }

    suspend fun getItemById(id: String): Response<RouteListingPreference.Item> {
        return apiService.getItemById(id)
    }

    suspend fun addItem(image: MultipartBody.Part, item: RequestBody, token: String): Response<ApiResponse> {
        return apiService.addItem(image, item, token)
    }

    suspend fun addItemToCart(cartItem: CartItem, token: String): Response<ApiResponse> {
        return apiService.addItemToCart(cartItem, token)
    }

    suspend fun updateItem(id: String, image: MultipartBody.Part, item: RequestBody, token: String): Response<ApiResponse> {
        return apiService.updateItem(id, image, item, token)
    }

    suspend fun deleteItem(id: String, token: String): Response<ApiResponse> {
        return apiService.deleteItem(id, token)
    }

    suspend fun getItemsByOwnerId(token: String): Response<List<RouteListingPreference.Item>> {
        return apiService.getItemsByOwnerId(token)
    }

    suspend fun checkout(token: String): Response<ApiResponse> {
        return apiService.checkout(token)
    }

    suspend fun updateCartItem(cartItem: CartItem, token: String): Response<ApiResponse> {
        return apiService.updateCartItem(cartItem, token)
    }

    suspend fun getCart(token: String): Response<List<CartItem>> {
        return apiService.getCart(token)
    }

    suspend fun deleteCartItem(cartItem: CartItem, token: String): Response<ApiResponse> {
        return apiService.deleteCartItem(cartItem, token)
    }

    suspend fun trackOrder(orderId: String, token: String): Response<OrderStatus> {
        return apiService.trackOrder(orderId, token)
    }
}*/
